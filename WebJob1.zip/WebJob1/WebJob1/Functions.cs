using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using Microsoft.WindowsAzure.Storage.Table;

namespace WebJob1
{
    public class Functions
    {
        // This function will get triggered/executed when a new message is written 
        // on an Azure Queue called queue.
        [NoAutomaticTrigger]
        public static async void ProcessQueueMessage(TextWriter log)
        {

            string connectionString = ConfigurationManager.ConnectionStrings["AzureWebJobsDashboard"].ConnectionString;

            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionString);

            // Create the queue client.
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

            // Retrieve a reference to a container.
            CloudQueue queue = queueClient.GetQueueReference("imagestoprocessqueue");

            CloudQueueMessage message = await queue.GetMessageAsync();

            if (message != null)
                Console.WriteLine(message.AsString);

            string blobId = message.AsString.Split('_')[0];
            string imageConversionMode = message.AsString.Split('_')[1];
            string containerName = message.AsString.Split('_')[2];

            // Create the table client.
            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

            // Create the CloudTable object that represents the "jobentity" table.
            CloudTable table = tableClient.GetTableReference("imageconversionjobs");

            TableOperation retrieveOperation = TableOperation.Retrieve<JobEntity>(imageConversionMode, blobId);
            TableResult retrievedResult = await table.ExecuteAsync(retrieveOperation);

            if (retrievedResult.Result != null)
                Console.WriteLine(((JobEntity)retrievedResult.Result).RowKey);

        }

    }
    public class JobEntity : TableEntity
    {
        public int status { get; set; }

        public string statusDescription { get; set; }

        public string imageSource { get; set; }

        public string imageResult { get; set; }

    }
}
