﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ImageProducer.DataTransferObjects
{
    /// <summary>
    /// The error response definition
    /// </summary>
    public class ErrorResponse
    {
        public int errorNumber { get; set; }
        public string parameterName { get; set; }
        public string parameterValue { get; set; }
        public string errorDescription { get; set; }

        public ErrorResponse(int errNum, string parName, string parVal)
        {
            (this.errorDescription, this.errorNumber) = ErrorResponse.GetErrorMessage(errNum);
            this.parameterName = parName;
            this.parameterValue = parVal;
        }

        /// <summary>
        /// Converts an error number inside an encoded error description, to the standard error response
        /// </summary>
        /// <param name="errorNumber">The error number</param>
        /// <returns>The decoded error message and number</returns>
        public static (string decodedErrorMessage, int decodedErrorNumber) GetErrorMessage(int errorNumber)
        {
            switch (errorNumber)
            {
                case 1:
                    {
                        return ("The entity already exists", errorNumber);
                    }
                case 2:
                    {
                        return ("The parameter value is too large", errorNumber);
                    }
                case 3:
                    {
                        return ("The parameter is required", errorNumber);
                    }
                case 4:
                    {
                        return ("The entity could not be found.", errorNumber);
                    }
                case 5:
                    {
                        return ("The parameter value is too small", errorNumber);
                    }
                case 6:
                    {
                        return ("The parameter cannot be null", errorNumber);
                    }
                case 7:
                    {
                        return ("The specifed resource name contains invalid characters", errorNumber);
                    }
                default:
                    {
                        return ($"Raw Error: {errorNumber}", errorNumber);
                    }

            }
        }

    }
}
