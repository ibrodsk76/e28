﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ImageProducer
{
    public static class ConfigSettings
    {
        public const string UPLOADED_IMAGES_CONTAINERNAME = "uploadedimages";

        public const string CONVERTED_IMAGES_CONTAINERNAME = "convertedimages";

        public const string FAILED_IMAGES_CONTAINERNAME = "failedimages";

        public const string STORAGE_CONNECTIONSTRING_NAME = "AzureWebJobsStorage";

        public const string JOBS_TABLENAME = "imageconversionjobs";

        public const string IMAGEJOBS_PARTITIONKEY = "imageconversions";

        public const string JOBID_METADATA_NAME = "JobId";

        public const string ConvertToGreyScaleRoute = "converttogreyscale/{name}";

        public const string ConvertToSepiaRoute = "converttosepia/{name}";

        public enum ImageConversionMode
        {
            GreyScale,
            Sepia
        }

        public enum ImageConversionStatus
        {
            ImageObtained = 1,
            ImageBeingConverted = 2,
            ImageConvertedSuccess = 3,
            ImageFailedConversion = 4
        }

    }
}
