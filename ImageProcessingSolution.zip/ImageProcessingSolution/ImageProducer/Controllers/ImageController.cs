﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using ImageProducer.DataTransferObjects;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace ImageProducer.Controllers
{
    /// <summary>
    /// Demo values controller
    /// Implements the <see cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    [Route("api/[controller]")]
    [ApiController]
    public class ImageController : ControllerBase
    {
        /// <summary>
        /// Logger instance
        /// </summary>
        private readonly ILogger _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="ImageController" /> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="logger">The logger.</param>
        public ImageController(ILogger<ImageController> logger)
        {
            _logger = logger;
           // Configuration = configuration;
        }
        /// <summary>
        /// Demo of a get
        /// </summary>
        /// <returns>Returns two values, value1 and value2</returns>
        [HttpGet]
        [ProducesResponseType(typeof(string[]), StatusCodes.Status200OK)]
        public ActionResult<IEnumerable<string>> Get()
        {
            // TODO: Provide your custom implementation here
            return new string[] { "value1", "value2" };
        }


        /// <summary>
        /// Gets the specified value by id.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>The value corresponding to the id</returns>
        [HttpGet("{id}")]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        public ActionResult<string> Get(int id)
        {
            // TODO: Provide your custom implementation here
            return $"value{id}";
        }


        // <summary>
        /// Updates or Create a file
        /// </summary>
        /// <param name="containername">Container name.</param>
        /// <param name="filename">File name.</param>
        /// <param name="fileData">The file.</param>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(void), StatusCodes.Status500InternalServerError)]
        [Route("api/v1/uploadedimages")]
        public async Task<IActionResult> CreateUpdateFile(IFormFile fileData)
        {
            try
            {
                ErrorResponse errorResponse = null;
                if (fileData == null)
                {
                    errorResponse = new ErrorResponse(6, "fileData", null);
                  //  _logger.LogInformation(LoggingEvents.InsertItem, null, errorResponse.errorDescription, errorResponse.parameterName);
                    return BadRequest(errorResponse);
                }

                // Get the storage account
                string storageConnectionString = Environment.GetEnvironmentVariable(ConfigSettings.STORAGE_CONNECTIONSTRING_NAME);
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(storageConnectionString);

                // Create the blob client.
                CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

                // Retrieve a reference to a container. 
                CloudBlobContainer container = blobClient.GetContainerReference(ConfigSettings.UPLOADED_IMAGES_CONTAINERNAME);

                // Create the container if it doesn't already exist.
                bool containerCreated = await container.CreateIfNotExistsAsync();

                if (containerCreated)
                {
                    // Set permissions on the blob container to allow public access
                    await container.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });
                }

                string blobId = Guid.NewGuid().ToString();

                // Retrieve reference to a blob
                CloudBlockBlob blockBlob = container.GetBlockBlobReference(blobId);

                // upload or update the file
                using (Stream uploadedFileStream = fileData.OpenReadStream())
                {
                    blockBlob.Properties.ContentType = fileData.ContentType;
                    await blockBlob.UploadFromStreamAsync(uploadedFileStream);

                }
            }
            catch (StorageException ex)
            {
              //  _logger.LogError(LoggingEvents.InternalError, ex, $"FileController CreateUpdateFile(containername=[{containername}]) caused an internal error.", containername);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
            catch (Exception ex)
            {
          //      _logger.LogError(LoggingEvents.InternalError, ex, $"FileController CreateFile(filename=[{filename}]) caused an internal error.", filename);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

            return NoContent();
        }



        /// <summary>
        /// Updates a value
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="value">The value.</param>
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status501NotImplemented)] // Remove once implemented
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public ActionResult Put(int id, [FromBody] string value)
        {
            // TODO: Implement
            return StatusCode(StatusCodes.Status501NotImplemented); // Remove once implemented
        }


        /// <summary>
        /// Deletes a value
        /// </summary>
        /// <param name="id">The identifier.</param>
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status501NotImplemented)] // Remove once implemented
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public ActionResult Delete(int id)
        {
            // TODO: Implement
            return StatusCode(StatusCodes.Status501NotImplemented); // Remove once implemented
        }
    }
}
